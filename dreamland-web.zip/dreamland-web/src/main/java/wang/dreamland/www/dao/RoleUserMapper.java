package wang.dreamland.www.dao;

import tk.mybatis.mapper.common.Mapper;
import wang.dreamland.www.entity.RoleUser;

public interface RoleUserMapper extends Mapper<RoleUser>{

}