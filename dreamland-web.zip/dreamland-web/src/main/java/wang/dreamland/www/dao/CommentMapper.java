package wang.dreamland.www.dao;

import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;
import wang.dreamland.www.entity.Comment;

import java.util.List;


public interface CommentMapper extends Mapper<Comment> {


}
