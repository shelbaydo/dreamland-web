package wang.dreamland.www.dao;

import tk.mybatis.mapper.common.Mapper;
import wang.dreamland.www.entity.UserContent;

import java.util.List;


public interface UserContentMapper extends Mapper<UserContent> {

}
