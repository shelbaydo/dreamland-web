package wang.dreamland.www.dao;

import tk.mybatis.mapper.common.Mapper;
import wang.dreamland.www.entity.Upvote;

public interface UpvoteMapper extends Mapper<Upvote>{

}