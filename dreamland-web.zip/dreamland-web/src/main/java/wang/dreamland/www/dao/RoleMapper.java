package wang.dreamland.www.dao;

import tk.mybatis.mapper.common.Mapper;
import wang.dreamland.www.entity.Role;

public interface RoleMapper extends Mapper<Role>{

}